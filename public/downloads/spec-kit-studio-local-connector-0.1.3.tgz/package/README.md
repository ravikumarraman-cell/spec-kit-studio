# Spec-Kit Studio local connector

This package is the local companion for a hosted Spec-Kit Studio UI. It listens only on `127.0.0.1`; it does not upload repositories or provider credentials.

## Start securely

```bash
export STUDIO_CONNECTOR_MODE=production
export STUDIO_ALLOWED_ROOTS="/absolute/path/to/your/studio-repositories"
export STUDIO_ALLOWED_ORIGINS="https://your-studio.example.com"
export STUDIO_CONNECTOR_TOKEN="a-long-random-value-of-at-least-32-bytes"
spec-kit-studio-connector
```

Open `http://127.0.0.1:4318/health` on the same computer. Then enter that URL and the pairing token in **Connected Workspace** in Studio.

Read the full guide at `docs/install-local-connector.md` in the Studio source distribution. Do not expose the connector on a LAN, put its token in a hosted environment, or allow a broad folder such as your home directory.
